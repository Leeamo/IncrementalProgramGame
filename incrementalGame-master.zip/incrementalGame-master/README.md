# Incremental Programming Game

This is a game that was written with Vue.js and vanilla JavaScript. It is an incremental game, like cookie clicker, where as well as purchasing upgrades the user can program their workers to perform different actions depending on certain variables.
